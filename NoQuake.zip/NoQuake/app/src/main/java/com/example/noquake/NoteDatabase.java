package com.example.architectureexample;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {Note.class}, version = 1)
public abstract class NoteDatabase extends RoomDatabase {

    private static NoteDatabase instance;
    public abstract NoteDao noteDao();
    public static synchronized NoteDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    NoteDatabase.class, "note_ddb")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }
    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsyncTask(instance).execute();
        }
    };
    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void> {
        private NoteDao noteDao;
        private PopulateDbAsyncTask(NoteDatabase db) {
            noteDao = db.noteDao();
        }
        @Override
        protected Void doInBackground(Void... voids) {
            noteDao.insert(new Note("MALATYA", "01.06.2020 / 12.09", 2.3));
            noteDao.insert(new Note("AKDENİZ", "01.06.2020 / 11.51", 3.0));
            noteDao.insert(new Note("ELAZIĞ", "01.06.2020 / 11.45", 1.0));
            noteDao.insert(new Note("AKDENIZ", "01.06.2020 / 11.32", 2.5));
            noteDao.insert(new Note("ELAZIĞ", "01.06.2020 / 10.45", 0.9));
            noteDao.insert(new Note("GAZIANTEP", "01.06.2020 / 10.34", 1.9));
            noteDao.insert(new Note("HATAY", "01.06.2020 / 10.28",  1.5));
            noteDao.insert(new Note("EGE DENİZİ", "01.06.2020 / 10.11",  1.4));
            noteDao.insert(new Note("MANİSA", "01.06.2020 / 09.57", 1.2));
            noteDao.insert(new Note("MANİSA", "01.06.2020 / 09.07",1.2));
            noteDao.insert(new Note("MANİSA", "01.06.2020 / 07.51", 1.7));
            noteDao.insert(new Note("AKDENIZ", "01.06.2020 / 06.17", 2.6));
            noteDao.insert(new Note("AKDENIZ", "01.06.2020 / 06.03", 3.1));
            noteDao.insert(new Note("AKDENIZ", "01.06.2020 / 05.44", 1.8));
            noteDao.insert(new Note("ELAZIĞ", "01.06.2020 / 05.21", 2.1));
            noteDao.insert(new Note("ELAZIĞ", "01.06.2020 / 04.43", 2.0));
            noteDao.insert(new Note("AKDENIZ", "01.06.2020 / 04.19", 2.8));
            noteDao.insert(new Note("AKDENIZ", "01.06.2020 / 03.51", 2.4));
            noteDao.insert(new Note("AKDENIZ", "01.06.2020 / 03.42", 2.3));
            noteDao.insert(new Note("ELAZIĞ", "01.06.2020 / 02.49", 1.4));
            noteDao.insert(new Note("AKDENIZ", "01.06.2020 / 02.41", 1.8));
            noteDao.insert(new Note("AKDENIZ", "01.06.2020 / 02.30", 2.1));
            noteDao.insert(new Note("KIRIKKALE", "01.06.2020 /01.39", 2.1));
            return null;
        }
    }
}

