package com.example.noquake;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Guide2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide2);
    }
}
