package com.portfolio.contactlist;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainFragment extends Fragment
{
    static MainViewModel mViewModel;
    static ContactListAdapter adapter = new ContactListAdapter(R.layout.card_layout);
    private EditText contactName;
    private EditText contactPhone;
    private EditText contactEmail;
    List<String> where = new ArrayList<String>();


    final int SEND_SMS_PERMISSION_REQUEST_CODE = 1;
    //CONSTRUCTOR
    public static MainFragment newInstance() { return new MainFragment(); }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        return inflater.inflate(R.layout.main_fragment, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(MainViewModel.class);

        contactName = Objects.requireNonNull(getView()).findViewById(R.id.contact_name);
        contactPhone = getView().findViewById(R.id.contact_phone);
        contactEmail = getView().findViewById(R.id.contact_email);
        recyclerSetup();
        observerSetup();

        FloatingActionButton fab = getView().findViewById(R.id.searchButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                String name = contactName.getText().toString();
                String phone = contactPhone.getText().toString();
                String email = contactEmail.getText().toString();
                where.add(phone);
                Contact contact = new Contact(name, phone, email);
                if (!name.equals("")) { mViewModel.findName(name); }
                else if (!phone.equals("")) { mViewModel.findPhone(phone); }
                else if (!email.equals("")) { mViewModel.findEmail(email); }
                else { MainActivity.toaster(getContext(), "You must enter criteria to search for"); }
                insertContact(contact, phone);
                clearFields();
            }
        });
        FloatingActionButton sendtxt = getView().findViewById(R.id.send);
        sendtxt.setEnabled(false);
        if (checkPermission(Manifest.permission.SEND_SMS)) {
            sendtxt.setEnabled(true);
        } else {
            ActivityCompat.requestPermissions((Activity) getContext(), new String[]{Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_REQUEST_CODE);
        }

        sendtxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendtext();
            }
        });

    }

    //CLEAR - Cannot call non-static MainActivity.clearFields() from static Fragment
    public void clearFields()
    {
        contactName.setText("");
        contactPhone.setText("");
        contactEmail.setText("");
        contactName.requestFocus();
    }

    public void insertContact (Contact contact, String phone)
    {
        if (!contact.getContactName().equals("") && !contact.getContactPhone().equals(""))
        {
            mViewModel.insertContact(contact);
        }
    }
    //Sorts the display adapter, not the data
    public void sort(boolean reverse) { adapter.sort(reverse); }

    //OBSERVER SETUP
    private void observerSetup()
    {
        mViewModel.getAllContacts().observe(getViewLifecycleOwner(), new Observer<List<Contact>>() {
            @Override
            public void onChanged(@Nullable final List<Contact> contacts)
            {
                adapter.setContactList(contacts);
            }
        });

        mViewModel.getSearchResults().observe(getViewLifecycleOwner(), new Observer<List<Contact>>() {
            @Override
            public void onChanged(@Nullable final List<Contact> contacts)
            {
                if (contacts.size() > 0)
                {
                    adapter.setContactList(contacts);
                }
                else
                {
                    mViewModel.findName("");
                    MainActivity.toaster(getContext(),"No matches found");
                }
            }
        });
    }

    //RECYCLER SETUP
    private void recyclerSetup()
    {
        RecyclerView recyclerView;
        recyclerView = Objects.requireNonNull(getView()).findViewById(R.id.contact_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
        adapter.setOnDeleteClickListener(new ContactListAdapter.OnDeleteClickListener()
        {
            public void onClick(String name)
            {
                mViewModel.deleteContact(name);
            }
        });
    }
    public void sendtext() {
        String[] simpleArray = new String[ where.size() ];
        where.toArray( simpleArray );
        for (int i = 0; i < where.size(); i++){
            String phoneNumber = simpleArray[i];
            String smsMessage = "GÜVENDEYİM";

            if (phoneNumber.length() == 1 || phoneNumber.length() == 0) {
                return;
            }
            if (checkPermission(Manifest.permission.SEND_SMS)) {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, smsMessage, null, null);
                Toast.makeText(getContext(), "Message Sent", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }

    }

    public boolean checkPermission(String permission) {
        int check = ContextCompat.checkSelfPermission(Objects.requireNonNull(getContext()), permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
}